from .ThermalReliefViaAction import ThermalReliefVia
ThermalReliefVia().register() # Instantiate and register to Pcbnew